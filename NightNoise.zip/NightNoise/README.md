# Night Noise

Gaussian white noise for Android with a whole-night volume schedule and Google Cast.

- Plays on the phone, or streams to a Cast speaker (Nest, Chromecast built-in).
- When casting, the app sets the speaker's own volume on schedule.
- Runs as a foreground service with wake and WiFi locks so it lasts the night.

Build: `gradle assembleDebug` (Gradle 8.7, JDK 17), or push to GitHub and let
`.github/workflows/build.yml` build it. The APK appears under the run's Artifacts.
