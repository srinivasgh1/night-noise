package app.nightnoise

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import java.io.BufferedOutputStream
import java.io.OutputStream
import java.nio.ByteOrder

/**
 * Encodes endless Gaussian noise to AAC and writes it as an ADTS stream,
 * the same format internet radio uses, which Cast speakers play natively.
 * Pacing comes from the network: writes block once the speaker has buffered enough.
 */
object AacStreamer {
    private const val RATE = 44100

    fun stream(out: OutputStream, keepGoing: () -> Boolean) {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 160_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
        val info = MediaCodec.BufferInfo()
        val noise = NoiseSource()
        val pcm = ShortArray(1024)
        val bos = BufferedOutputStream(out, 16384)
        var pts = 0L
        try {
            while (keepGoing()) {
                val inIdx = codec.dequeueInputBuffer(5000)
                if (inIdx >= 0) {
                    val buf = codec.getInputBuffer(inIdx)!!
                    buf.clear()
                    val n = minOf(pcm.size, buf.remaining() / 2)
                    noise.fill(pcm, n)
                    buf.order(ByteOrder.nativeOrder()).asShortBuffer().put(pcm, 0, n)
                    codec.queueInputBuffer(inIdx, 0, n * 2, pts, 0)
                    pts += n * 1_000_000L / RATE
                }
                var outIdx = codec.dequeueOutputBuffer(info, 5000)
                var wrote = false
                while (outIdx >= 0) {
                    val ob = codec.getOutputBuffer(outIdx)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0 && info.size > 0) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val frame = ByteArray(info.size)
                        ob.get(frame)
                        bos.write(adts(info.size + 7))
                        bos.write(frame)
                        wrote = true
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    outIdx = codec.dequeueOutputBuffer(info, 0)
                }
                if (wrote) bos.flush()
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
        }
    }

    /** 7-byte ADTS header: AAC-LC, 44.1 kHz, mono. */
    private fun adts(len: Int): ByteArray {
        val profile = 2
        val freq = 4
        val chan = 1
        return byteArrayOf(
            0xFF.toByte(),
            0xF1.toByte(),
            (((profile - 1) shl 6) + (freq shl 2) + (chan shr 2)).toByte(),
            (((chan and 3) shl 6) + (len shr 11)).toByte(),
            ((len and 0x7FF) shr 3).toByte(),
            (((len and 7) shl 5) + 0x1F).toByte(),
            0xFC.toByte()
        )
    }
}
