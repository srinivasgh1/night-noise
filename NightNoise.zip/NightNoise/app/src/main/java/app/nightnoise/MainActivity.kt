package app.nightnoise

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var settings: Settings
    private lateinit var rows: LinearLayout
    private lateinit var chart: ScheduleChartView
    private lateinit var bigVolume: TextView
    private lateinit var status: TextView
    private lateinit var startBtn: MaterialButton

    private val ui = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() { render(); ui.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rows = findViewById(R.id.rows)
        chart = findViewById(R.id.chart)
        bigVolume = findViewById(R.id.bigVolume)
        status = findViewById(R.id.status)
        startBtn = findViewById(R.id.startBtn)

        val castButton = findViewById<MediaRouteButton>(R.id.castButton)
        try {
            CastContext.getSharedInstance(this)
            CastButtonFactory.setUpMediaRouteButton(applicationContext, castButton)
        } catch (e: Exception) {
            castButton.visibility = View.GONE
            findViewById<TextView>(R.id.castHint).text = "Casting needs Google Play services, which isn’t available on this phone."
        }

        settings = Schedule.load(this)
        chart.settings = settings

        startBtn.setOnClickListener {
            if (PlaybackState.running) {
                startService(Intent(this, NoiseService::class.java).setAction(NoiseService.ACTION_STOP))
            } else {
                askNotificationPermission()
                ContextCompat.startForegroundService(
                    this, Intent(this, NoiseService::class.java).setAction(NoiseService.ACTION_START)
                )
                PlaybackState.status = "Starting…"
            }
        }

        findViewById<MaterialButton>(R.id.addBtn).setOnClickListener {
            val last = Schedule.sorted(settings).lastOrNull()
            val m = if (last != null) (last.minutes + 60) % 1440 else 22 * 60
            settings.points.add(Point(m, last?.volume ?: 40))
            changed(); renderRows()
        }

        findViewById<SwitchMaterial>(R.id.fadeSwitch).apply {
            isChecked = settings.fade
            setOnCheckedChangeListener { _, on -> settings.fade = on; changed() }
        }
        findViewById<SwitchMaterial>(R.id.fadeInSwitch).apply {
            isChecked = settings.fadeIn
            setOnCheckedChangeListener { _, on -> settings.fadeIn = on; changed() }
        }
        findViewById<SwitchMaterial>(R.id.stopSwitch).apply {
            isChecked = settings.stopAtEnd
            setOnCheckedChangeListener { _, on -> settings.stopAtEnd = on; changed() }
        }
        val ceilingVal = findViewById<TextView>(R.id.ceilingVal)
        findViewById<SeekBar>(R.id.ceiling).apply {
            progress = settings.maxSpeaker
            ceilingVal.text = "${settings.maxSpeaker}%"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    settings.maxSpeaker = maxOf(5, p); ceilingVal.text = "${settings.maxSpeaker}%"; changed()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }

        renderRows()
    }

    override fun onResume() { super.onResume(); ui.post(refresh) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(refresh) }

    private fun changed() {
        Schedule.save(this, settings)
        chart.invalidate()
    }

    private fun renderRows() {
        rows.removeAllViews()
        settings.points.sortBy { Schedule.nightKey(it.minutes) }
        val inflater = LayoutInflater.from(this)
        for (p in settings.points) {
            val row = inflater.inflate(R.layout.row_point, rows, false)
            val time = row.findViewById<MaterialButton>(R.id.time)
            val seek = row.findViewById<SeekBar>(R.id.seek)
            val value = row.findViewById<TextView>(R.id.value)
            val del = row.findViewById<ImageButton>(R.id.del)

            time.text = Schedule.fmt(p.minutes)
            seek.progress = p.volume
            value.text = "${p.volume}%"

            time.setOnClickListener {
                TimePickerDialog(this, { _, hh, mm ->
                    p.minutes = hh * 60 + mm
                    changed(); renderRows()
                }, p.minutes / 60, p.minutes % 60, true).show()
            }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, prog: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    p.volume = prog; value.text = "$prog%"; changed()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
            del.setOnClickListener {
                settings.points.remove(p)
                changed(); renderRows()
            }
            rows.addView(row)
        }
    }

    private fun render() {
        val running = PlaybackState.running
        val v = if (running) PlaybackState.volume
                else Schedule.volumeAt(settings, System.currentTimeMillis()).roundToInt()
        bigVolume.text = "$v%"
        startBtn.text = if (running) "Stop" else "Start"
        status.text = if (running || PlaybackState.status != "Stopped") PlaybackState.status
                      else "Stopped. The schedule is at $v% right now."
        chart.invalidate()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }
}
