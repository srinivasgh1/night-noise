package app.nightnoise

/** Shared between the service and the screen. */
object PlaybackState {
    @Volatile var running = false
    @Volatile var status = "Stopped"
    @Volatile var volume = 0
}
