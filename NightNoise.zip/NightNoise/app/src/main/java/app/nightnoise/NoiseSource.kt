package app.nightnoise

import java.util.Random

/** Gaussian white noise as 16-bit PCM. */
class NoiseSource(private val sigma: Double = 0.2) {
    private val rnd = Random()

    fun fill(buf: ShortArray, n: Int = buf.size) {
        for (i in 0 until n) {
            val x = (rnd.nextGaussian() * sigma).coerceIn(-1.0, 1.0)
            buf[i] = (x * 32767).toInt().toShort()
        }
    }
}
