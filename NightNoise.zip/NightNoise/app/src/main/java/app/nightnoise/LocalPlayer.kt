package app.nightnoise

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

/** Plays the noise on the phone itself. */
class LocalPlayer {
    @Volatile private var running = false
    private var track: AudioTrack? = null
    private var thread: Thread? = null

    fun start() {
        val rate = 44100
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(min * 4)
            .build()
        t.setVolume(0f)
        t.play()
        track = t
        running = true
        thread = Thread({
            val src = NoiseSource()
            val buf = ShortArray(2048)
            while (running) {
                src.fill(buf)
                if (t.write(buf, 0, buf.size) < 0) break
            }
        }, "noise-local").apply { start() }
    }

    fun setGain(g: Float) {
        track?.setVolume(g.coerceIn(0f, 1f))
    }

    fun stop() {
        running = false
        track?.let {
            try { it.pause(); it.flush() } catch (_: Exception) {}
        }
        thread?.join(500)
        track?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        track = null
        thread = null
    }
}
