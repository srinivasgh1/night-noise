package app.nightnoise

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import java.util.Calendar

/** Draws tonight's volume curve with a marker for now. */
class ScheduleChartView(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {

    var settings: Settings? = null

    private val d = resources.displayMetrics.density
    private val accent = ContextCompat.getColor(ctx, R.color.accent)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(ctx, R.color.line); strokeWidth = d
    }
    private val curvePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent; style = Paint.Style.STROKE; strokeWidth = 2.5f * d
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; alpha = 36 }
    private val dotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ContextCompat.getColor(ctx, R.color.surface) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(ctx, R.color.muted); textSize = 11 * d
    }
    private val nowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(ctx, R.color.ink); strokeWidth = 1.5f * d
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = settings ?: return
        val now = System.currentTimeMillis()
        val tl = Schedule.timeline(s, now)
        if (tl.isEmpty()) return

        val left = 30 * d; val right = 8 * d; val top = 12 * d; val bottom = 22 * d
        val w = width.toFloat(); val h = height.toFloat()
        var t0 = tl.first().first - 30 * 60_000L
        val t1 = tl.last().first + 60 * 60_000L
        if (now > t0 - 3 * 3_600_000L && now < t1) t0 = minOf(t0, now - 10 * 60_000L)

        fun x(t: Long) = left + (t - t0).toFloat() / (t1 - t0) * (w - left - right)
        fun y(v: Double) = top + (1 - v / 100).toFloat() * (h - top - bottom)

        textPaint.textAlign = Paint.Align.RIGHT
        for (v in listOf(0.0, 50.0, 100.0)) {
            canvas.drawLine(left, y(v), w - right, y(v), gridPaint)
            canvas.drawText(v.toInt().toString(), left - 6 * d, y(v) + 4 * d, textPaint)
        }
        textPaint.textAlign = Paint.Align.CENTER
        val spanH = (t1 - t0) / 3_600_000.0
        val step = if (spanH > 10) 3 else if (spanH > 5) 2 else 1
        val c = Calendar.getInstance().apply {
            timeInMillis = t0; set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            add(Calendar.HOUR_OF_DAY, 1)
        }
        while (c.timeInMillis < t1) {
            if (c.get(Calendar.HOUR_OF_DAY) % step == 0) {
                canvas.drawText("%02d:00".format(c.get(Calendar.HOUR_OF_DAY)), x(c.timeInMillis), h - 6 * d, textPaint)
            }
            c.add(Calendar.HOUR_OF_DAY, 1)
        }

        val path = Path()
        val area = Path()
        var t = t0
        var first = true
        while (t <= t1) {
            val px = x(t); val py = y(Schedule.volumeAt(s, t, tl))
            if (first) { path.moveTo(px, py); area.moveTo(px, y(0.0)); area.lineTo(px, py); first = false }
            else { path.lineTo(px, py); area.lineTo(px, py) }
            t += 30_000L
        }
        area.lineTo(x(t1), y(0.0)); area.close()
        canvas.drawPath(area, fillPaint)
        canvas.drawPath(path, curvePaint)

        for ((pt, pv) in tl) {
            canvas.drawCircle(x(pt), y(pv.toDouble()), 4 * d, dotFill)
            canvas.drawCircle(x(pt), y(pv.toDouble()), 4 * d, curvePaint)
        }
        if (now in t0..t1) {
            val nx = x(now)
            canvas.drawLine(nx, top - 4 * d, nx, h - bottom, nowPaint)
            canvas.drawCircle(nx, y(Schedule.volumeAt(s, now, tl)), 5 * d, nowPaint)
        }
    }
}
