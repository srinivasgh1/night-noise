package app.nightnoise

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections

/** Tiny HTTP server on the phone that the speaker pulls the noise stream from. */
class NoiseServer {
    private var server: ServerSocket? = null
    @Volatile private var running = false
    private val clients: MutableList<Socket> = Collections.synchronizedList(mutableListOf())

    val port: Int get() = server?.localPort ?: -1

    fun start() {
        val s = try { ServerSocket(8765) } catch (e: IOException) { ServerSocket(0) }
        server = s
        running = true
        Thread({
            while (running) {
                val c = try { s.accept() } catch (e: IOException) { break }
                clients.add(c)
                Thread({ handle(c) }, "noise-client").start()
            }
        }, "noise-server").start()
    }

    private fun handle(c: Socket) {
        try {
            c.tcpNoDelay = true
            val reader = BufferedReader(InputStreamReader(c.getInputStream()))
            val request = reader.readLine() ?: return
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isEmpty()) break
            }
            val out = c.getOutputStream()
            val head = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: audio/aac\r\n" +
                "Cache-Control: no-cache, no-store\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Connection: close\r\n\r\n"
            out.write(head.toByteArray())
            out.flush()
            if (!request.startsWith("GET")) return
            AacStreamer.stream(out) { running && !c.isClosed }
        } catch (_: Exception) {
        } finally {
            clients.remove(c)
            try { c.close() } catch (_: Exception) {}
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        synchronized(clients) {
            clients.forEach { try { it.close() } catch (_: Exception) {} }
            clients.clear()
        }
        server = null
    }
}
