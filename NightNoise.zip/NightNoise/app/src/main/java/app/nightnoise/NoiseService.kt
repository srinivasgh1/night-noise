package app.nightnoise

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import java.net.Inet4Address
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Runs all night as a foreground service. Plays on the phone, or, when a Cast
 * speaker is connected, streams to it and sets the speaker's volume on schedule.
 */
class NoiseService : Service() {

    companion object {
        const val ACTION_START = "app.nightnoise.START"
        const val ACTION_STOP = "app.nightnoise.STOP"
        private const val NOTIF_ID = 1
        private const val CHANNEL = "playback"
    }

    private enum class Mode { NONE, LOCAL, CAST }

    private val handler = Handler(Looper.getMainLooper())
    private var mode = Mode.NONE
    private var player: LocalPlayer? = null
    private var server: NoiseServer? = null
    private var castSession: CastSession? = null
    private var castContext: CastContext? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var startedAt = 0L
    private var endedAtStart = false
    private var lastCastVol = -1.0

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) = onSpeakerConnected(session)
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) = onSpeakerConnected(session)
        override fun onSessionEnded(session: CastSession, error: Int) {
            if (mode == Mode.CAST) stopPlayback("Speaker disconnected")
        }
        override fun onSessionStarting(session: CastSession) {}
        override fun onSessionStartFailed(session: CastSession, error: Int) {}
        override fun onSessionEnding(session: CastSession) {}
        override fun onSessionResuming(session: CastSession, sessionId: String) {}
        override fun onSessionResumeFailed(session: CastSession, error: Int) {}
        override fun onSessionSuspended(session: CastSession, reason: Int) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopPlayback("Stopped")
            else -> if (mode == Mode.NONE) startPlayback()
        }
        return START_NOT_STICKY
    }

    private fun startPlayback() {
        createChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification("Starting…"),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        )
        acquireLocks()

        startedAt = System.currentTimeMillis()
        val s = Schedule.load(this)
        endedAtStart = Schedule.isFinished(s, startedAt)
        lastCastVol = -1.0

        castContext = try { CastContext.getSharedInstance(this) } catch (e: Exception) { null }
        castContext?.sessionManager?.addSessionManagerListener(sessionListener, CastSession::class.java)
        val session = castContext?.sessionManager?.currentCastSession

        PlaybackState.running = true
        if (session != null && session.isConnected) startCast(session) else startLocal()
        if (mode != Mode.NONE) handler.post(tick)
    }

    private fun onSpeakerConnected(session: CastSession) {
        if (mode == Mode.LOCAL) {
            player?.stop()
            player = null
            startCast(session)
        }
    }

    private fun startLocal() {
        player = LocalPlayer().also { it.start() }
        mode = Mode.LOCAL
    }

    private fun startCast(session: CastSession) {
        val ip = wifiIp() ?: run { stopPlayback("The phone isn’t on WiFi"); return }
        val srv = server ?: NoiseServer().also { it.start(); server = it }
        val url = "http://$ip:${srv.port}/noise.aac"
        val meta = MediaMetadata(MediaMetadata.MEDIA_TYPE_MUSIC_TRACK).apply {
            putString(MediaMetadata.KEY_TITLE, "White noise")
            putString(MediaMetadata.KEY_ARTIST, "Night Noise")
        }
        val info = MediaInfo.Builder(url)
            .setStreamType(MediaInfo.STREAM_TYPE_LIVE)
            .setContentType("audio/aac")
            .setMetadata(meta)
            .build()
        castSession = session
        mode = Mode.CAST
        lastCastVol = -1.0
        if (Schedule.load(this).fadeIn) setCastVolume(0.0)
        session.remoteMediaClient?.load(
            MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).build()
        )
    }

    private val tick = object : Runnable {
        override fun run() {
            if (mode == Mode.NONE) return
            val now = System.currentTimeMillis()
            val s = Schedule.load(this@NoiseService)
            if (!endedAtStart && Schedule.isFinished(s, now)) {
                stopPlayback("Schedule finished")
                return
            }
            val v = if (endedAtStart) (Schedule.sorted(s).firstOrNull()?.volume ?: 0).toDouble()
                    else Schedule.volumeAt(s, now)
            val elapsed = now - startedAt
            val factor = if (s.fadeIn) (elapsed / 5000.0).coerceIn(0.0, 1.0) else 1.0
            applyVolume(v * factor, s)

            PlaybackState.volume = v.roundToInt()
            PlaybackState.status = statusText(s, now)
            if (elapsed >= 6000 || elapsed < 600) updateNotification(PlaybackState.status)
            handler.postDelayed(this, if (elapsed < 6000) 500L else 15_000L)
        }
    }

    private fun applyVolume(v: Double, s: Settings) {
        when (mode) {
            Mode.LOCAL -> {
                val x = (v / 100.0).toFloat()
                player?.setGain(x * x)   // perceptual curve
            }
            Mode.CAST -> {
                // The speaker's volume scale is already perceptual
                val target = (v / 100.0) * (s.maxSpeaker / 100.0)
                if (abs(target - lastCastVol) >= 0.005) setCastVolume(target)
            }
            Mode.NONE -> {}
        }
    }

    private fun setCastVolume(v: Double) {
        try {
            castSession?.volume = v.coerceIn(0.0, 1.0)
            lastCastVol = v
        } catch (_: Exception) {}
    }

    private fun statusText(s: Settings, now: Long): String {
        val where = if (mode == Mode.CAST) "on ${castSession?.castDevice?.friendlyName ?: "speaker"}" else "on this phone"
        if (endedAtStart) return "Playing $where. Tonight’s schedule already ended."
        val next = Schedule.nextChange(s, now)
        return if (next != null) {
            val cal = java.util.Calendar.getInstance().apply { timeInMillis = next.first }
            val m = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
            "Playing $where. Next: ${next.second}% at ${Schedule.fmt(m)}"
        } else if (s.stopAtEnd) "Fading out $where" else "Playing $where at the last volume"
    }

    private fun stopPlayback(message: String) {
        handler.removeCallbacks(tick)
        if (mode == Mode.CAST) {
            try { castSession?.remoteMediaClient?.stop() } catch (_: Exception) {}
        }
        server?.stop(); server = null
        player?.stop(); player = null
        castSession = null
        mode = Mode.NONE
        castContext?.sessionManager?.removeSessionManagerListener(sessionListener, CastSession::class.java)
        releaseLocks()
        PlaybackState.running = false
        PlaybackState.status = message
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (mode != Mode.NONE) stopPlayback("Stopped")
        super.onDestroy()
    }

    private fun wifiIp(): String? {
        val cm = getSystemService(ConnectivityManager::class.java)
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                !caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) continue
            val lp = cm.getLinkProperties(n) ?: continue
            lp.linkAddresses.map { it.address }
                .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
                ?.let { return it.hostAddress }
        }
        return null
    }

    private fun acquireLocks() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NightNoise::play").apply {
            setReferenceCounted(false)
            acquire(14 * 60 * 60 * 1000L)
        }
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val wifiMode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                       else WifiManager.WIFI_MODE_FULL_HIGH_PERF
        wifiLock = wm.createWifiLock(wifiMode, "NightNoise").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseLocks() {
        try { wakeLock?.release() } catch (_: Exception) {}
        try { wifiLock?.release() } catch (_: Exception) {}
        wakeLock = null
        wifiLock = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Playback", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(R.drawable.ic_stat)
        .setContentTitle("White noise")
        .setContentText(text)
        .setOngoing(true)
        .setSilent(true)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .addAction(
            R.drawable.ic_close, "Stop",
            PendingIntent.getService(
                this, 1, Intent(this, NoiseService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }
}
