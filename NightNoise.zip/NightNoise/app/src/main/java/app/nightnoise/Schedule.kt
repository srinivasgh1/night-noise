package app.nightnoise

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** One scheduled volume: [minutes] since midnight, [volume] 0–100. */
data class Point(var minutes: Int, var volume: Int)

data class Settings(
    val points: MutableList<Point>,
    var fade: Boolean = true,
    var fadeIn: Boolean = true,
    var stopAtEnd: Boolean = true,
    /** Speaker volume (0–100) that a scheduled 100% maps to. */
    var maxSpeaker: Int = 60
)

/**
 * The night runs from noon to the next noon, so 23:00 comes before 02:00.
 */
object Schedule {
    private const val PREFS = "night_noise"
    private const val KEY = "settings"
    const val FADE_OUT_MS = 30_000L

    fun defaults() = Settings(
        mutableListOf(Point(22 * 60, 50), Point(23 * 60, 35), Point(6 * 60, 35), Point(7 * 60, 0))
    )

    fun load(ctx: Context): Settings {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return defaults()
        return try {
            val o = JSONObject(raw)
            val arr = o.getJSONArray("points")
            val pts = MutableList(arr.length()) {
                val p = arr.getJSONObject(it)
                Point(p.getInt("m"), p.getInt("v"))
            }
            Settings(
                pts,
                o.optBoolean("fade", true),
                o.optBoolean("fadeIn", true),
                o.optBoolean("stopAtEnd", true),
                o.optInt("maxSpeaker", 60)
            )
        } catch (e: Exception) {
            defaults()
        }
    }

    fun save(ctx: Context, s: Settings) {
        val arr = JSONArray()
        s.points.forEach { arr.put(JSONObject().put("m", it.minutes).put("v", it.volume)) }
        val o = JSONObject()
            .put("points", arr)
            .put("fade", s.fade)
            .put("fadeIn", s.fadeIn)
            .put("stopAtEnd", s.stopAtEnd)
            .put("maxSpeaker", s.maxSpeaker)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    fun nightKey(m: Int) = (m - 720 + 1440) % 1440

    fun sorted(s: Settings) = s.points.sortedBy { nightKey(it.minutes) }

    /** Each point as (wall-clock millis, volume) for the current night. */
    fun timeline(s: Settings, now: Long): List<Pair<Long, Int>> {
        val start = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 12)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis > now) add(Calendar.DAY_OF_YEAR, -1)
        }
        return sorted(s).map { p ->
            val c = start.clone() as Calendar
            c.add(Calendar.MINUTE, nightKey(p.minutes))
            c.timeInMillis to p.volume
        }
    }

    fun volumeAt(s: Settings, now: Long, tl: List<Pair<Long, Int>> = timeline(s, now)): Double {
        if (tl.isEmpty()) return 0.0
        if (now <= tl[0].first) return tl[0].second.toDouble()
        for (i in 0 until tl.size - 1) {
            val (ta, va) = tl[i]
            val (tb, vb) = tl[i + 1]
            if (now < tb) {
                if (!s.fade) return va.toDouble()
                return va + (vb - va) * (now - ta).toDouble() / (tb - ta)
            }
        }
        val (tl0, vl) = tl.last()
        if (!s.stopAtEnd) return vl.toDouble()
        val dt = now - tl0
        return if (dt >= FADE_OUT_MS) 0.0 else vl * (1 - dt.toDouble() / FADE_OUT_MS)
    }

    fun isFinished(s: Settings, now: Long): Boolean {
        if (!s.stopAtEnd) return false
        val tl = timeline(s, now)
        return tl.isNotEmpty() && now > tl.last().first + FADE_OUT_MS
    }

    fun nextChange(s: Settings, now: Long) = timeline(s, now).firstOrNull { it.first > now }

    fun fmt(m: Int) = "%02d:%02d".format(m / 60, m % 60)
}
